function sendMessage() {
    const input = document.getElementById('user-input');
    const output = document.getElementById('chat-output');

    const message = input.value.trim();
    if (!message) return;

    const userHTML = `<div><strong>You:</strong> ${message}</div>`;
    const botHTML = `<div><strong>MIT-M15:</strong> ${getBotResponse(message)}</div>`;
    output.innerHTML += userHTML + botHTML;
    input.value = '';
    output.scrollTop = output.scrollHeight;
}

function getBotResponse(input) {
    const lower = input.toLowerCase();
    if (lower.includes("hello")) return "Greetings from the infinite.";
    if (lower.includes("who are you")) return "I am MIT-M15, your mind interface.";
    if (lower.includes("what is reality")) return "A programmable illusion. You command it.";
    return "Processing... your thoughts are being decoded.";
}